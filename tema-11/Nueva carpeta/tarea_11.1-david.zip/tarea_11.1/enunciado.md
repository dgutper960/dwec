## Enunciado 11.1

Realizar la misma tarea del tema 10, pero utilizando la API fetch ( ) con promesas y con Async/Await, es decir, solo se trata de cambiar la(s) solicitud(es) AJAX que se hacen con el objeto XMLHttpRequest  por el método fetch( ), usando primero .then (promises), y luego comentando el anterior usaremos Async/Await  (en el mismo archivo).

#### Todo lo demás exactamente igual que la tarea del tema 10, no hay que modificar los archivos PHP.