## Enunciado 12.1

Realizar la misma tarea del tema 11, pero utilizando JQuery.

#### Todo lo demás exactamente igual que la tarea del tema 11, no hay que modificar los archivos PHP.